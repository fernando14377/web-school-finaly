function updateClock() {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    const timeString = `${hours}:${minutes}:${seconds}`;
    
    document.getElementById('time').innerText = timeString;
}

// Actualizar el reloj cada segundo
setInterval(updateClock, 1000);

let meses = [
    "Domingo",
    "Lunes",
    "Martes",
    "Miercoles",
    "Jueves",
    "Viernes"
]
// Llamar a updateClock() para mostrar la hora inmediatamente
updateClock();
function updateDate() {
    const now = new Date();
    const dayOfTheWeekIndex = now.getDay();
    const dayOfTheWeek = meses[dayOfTheWeekIndex];
    const day = now.getDate();
    const month = now.toLocaleString('default', { month: 'long' }); // Obtiene el nombre completo del mes
    const year = now.getFullYear();

    const dateElement = document.getElementById('date');
    dateElement.textContent += `${dayOfTheWeek} ${month} ${day}, ${year}`;
}

// Llamar a updateDate() para mostrar la fecha en el encabezado
updateDate();

const list = document.getElementById("list");
const listLink = document.querySelectorAll("li__info");

let moveMargin = 90;

const body = document.getElementById("body");

function toggleBach() {
    if (body.style.background == "white") {
        body.style.background = "black";
    } else {
        body.style.background = "white"
    }
}


//carousel 
let currentSlide = 0;

function move(n) {
    const items = document.querySelectorAll('.carousel-item');
    currentSlide += n;
    if (currentSlide < 0) {
        currentSlide = items.length - 1;
    }
    if (currentSlide >= items.length) {
        currentSlide = 0;
    }
    items.forEach(item => item.classList.remove('opacity-100'));
    items[currentSlide].classList.add('opacity-100');
}
// scrool reveal

ScrollReveal().reveal('#header', { duration: 500 });
ScrollReveal().reveal('#banner', { duration: 500 });
ScrollReveal().reveal('#titulares', { duration: 500 });
ScrollReveal().reveal('#banner', { duration: 500 });

